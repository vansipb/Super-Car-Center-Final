﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SuperCarCenter
{
    public class Controller
    {
        #region ENUMERABLES


        #endregion

        #region FIELDS

        bool active = true;

        #endregion

        #region PROPERTIES


        #endregion

        #region CONSTRUCTORS

        public Controller()
        {
            ApplicationControl();
        }

        #endregion

        #region METHODS

        private void ApplicationControl()
        {
            AppEnum.ManagerAction userActionChoice;

            ConsoleView.DisplayWelcomeScreen();

            while (active)
            {
                userActionChoice = ConsoleView.GetUserActionChoice();

                switch (userActionChoice)
                {
                    case AppEnum.ManagerAction.None:
                        break;

                    case AppEnum.ManagerAction.ListCarInventory:
                        ListAllCarInventory();
                        break;

                    case AppEnum.ManagerAction.DisplayCarInfo:
                        DisplayCarInformation();
                        break;

                    case AppEnum.ManagerAction.QuerySuperCarsByPrice:
                        QueryPriceRange();
                        break;

                    case AppEnum.ManagerAction.QuerySuperCarsByHp:
                        QueryHpRange();
                        break;

                    case AppEnum.ManagerAction.AddCarInfo:
                        AddCarInfo();
                        break;

                    case AppEnum.ManagerAction.UpdateCarInfo:
                        UpdateCarInfo();
                        break;

                    case AppEnum.ManagerAction.DeleteCarInfo:
                        DeleteCarInfo();
                        break;

                    case AppEnum.ManagerAction.Quit:
                        active = false;
                        break;

                    default:
                        break;
                }

            }

            ConsoleView.DisplayExitPrompt();
        }

        private static void ListAllCarInventory()
        {
            SuperCarRepoSQL superCarRepository = new SuperCarRepoSQL();
            List<CarInfo> superCar;

            using (superCarRepository)
            {
                superCar = superCarRepository.SelectAll();
                ConsoleView.DisplayAllSuperCars(superCar);
                ConsoleView.DisplayContinuePrompt();
            }
        }

        private static void DisplayCarInformation()
        {
            SuperCarRepoSQL superCarRepository = new SuperCarRepoSQL();
            List<CarInfo> SuperCar;
            CarInfo superCar = new CarInfo();
            int superCarID;

            using (superCarRepository)
            {
                SuperCar = superCarRepository.SelectAll();
                superCarID = ConsoleView.GetSuperCarID(SuperCar);
                superCar = superCarRepository.SelectById(superCarID);
            }

            ConsoleView.DisplayCarInfo(superCar);
            ConsoleView.DisplayContinuePrompt();
        }

        private static void AddCarInfo()
        {
            SuperCarRepoSQL superCarRepository = new SuperCarRepoSQL();
            CarInfo superCar = new CarInfo();

            superCar = ConsoleView.AddCarInfo();
            using (superCarRepository)
            {
                superCarRepository.Add(superCar);
            }

            ConsoleView.DisplayContinuePrompt();
        }

        private static void UpdateCarInfo()
        {
            SuperCarRepoSQL superCarRepository = new SuperCarRepoSQL();
            List<CarInfo> SuperCar = superCarRepository.SelectAll();
            CarInfo superCar = new CarInfo();
            int superCarID;

            using (superCarRepository)
            {
                SuperCar = superCarRepository.SelectAll();
                superCarID = ConsoleView.GetSuperCarID(SuperCar);
                superCar = superCarRepository.SelectById(superCarID);
                superCar = ConsoleView.UpdateCarInfo(superCar);
                superCarRepository.Update(superCar);
            }
        }

        private static void DeleteCarInfo()
        {
            SuperCarRepoSQL superCarRepository = new SuperCarRepoSQL();
            List<CarInfo> superCar = superCarRepository.SelectAll();
            CarInfo SuperCar = new CarInfo();
            int superCarID;
            string message;

            superCarID = ConsoleView.GetSuperCarID(superCar);

            using (superCarRepository)
            {
                superCarRepository.Delete(superCarID);
            }

            ConsoleView.DisplayReset();

            // TODO refactor
            message = String.Format("Car ID: {0} had been deleted.", superCarID);

            ConsoleView.DisplayMessage(message);
            ConsoleView.DisplayContinuePrompt();
        }

        private static void QueryPriceRange()
        {
            SuperCarRepoSQL superCarRepository = new SuperCarRepoSQL();
            IEnumerable<CarInfo> matchingSuperCar = new List<CarInfo>();
            int minimumPrice;
            int maximumPrice;

            ConsoleView.GetPriceQueryMinMaxValues(out minimumPrice, out maximumPrice);

            using (superCarRepository)
            {
                matchingSuperCar = superCarRepository.QueryByPrice(minimumPrice, maximumPrice);
            }

            ConsoleView.DisplayQueryResults(matchingSuperCar);
            ConsoleView.DisplayContinuePrompt();
        }

        private static void QueryHpRange()
        {
            SuperCarRepoSQL superCarRepository = new SuperCarRepoSQL();
            IEnumerable<CarInfo> matchingSuperCar = new List<CarInfo>();
            int minimumHorsePower;
            int maximumHorsePwer;

            ConsoleView.GetHPQueryMinMaxValues(out minimumHorsePower, out maximumHorsePwer);

            using (superCarRepository)
            {
                matchingSuperCar = superCarRepository.QueryByHorsePower(minimumHorsePower, maximumHorsePwer);
            }

            ConsoleView.DisplayHpResults(matchingSuperCar);
            ConsoleView.DisplayContinuePrompt();
        }


        #endregion

    }
}
